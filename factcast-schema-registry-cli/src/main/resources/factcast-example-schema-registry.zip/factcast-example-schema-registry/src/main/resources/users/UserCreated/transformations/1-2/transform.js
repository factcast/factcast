function transform(event) {
    event.salutation = "NA"
}
