function transform(event) {
    // just a dummy downcast transformation
}