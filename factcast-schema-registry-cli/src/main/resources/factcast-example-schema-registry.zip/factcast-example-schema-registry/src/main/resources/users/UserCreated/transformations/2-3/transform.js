function transform(event) {
    event.displayName = event.firstName + " " + event.lastName
}