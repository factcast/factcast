This namespace contains all user related events.

