Use this directory to add third party extensions to Maven Core. These extensions can either extend or override
Maven's default implementation.
